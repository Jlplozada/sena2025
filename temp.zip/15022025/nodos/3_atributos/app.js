// importaciones 
// variables const
const input = document.querySelector(`input`);
const contrasena = document.querySelector(`input[type="password"]`);
const formulario = document.querySelector(`form`);
const btn_validar = document.querySelector(`button`);
console.log(input);
console.log(contrasena);
console.log(input.type);
console.log(input.value);
console.log(input.placeholder);
input.value="jose paez";
console.log(contrasena.value ? `lleno`:`vacio`);
contrasena.value="123456";
// contrasena.type = "text";
contrasena.setAttribute("type", "text")// metodos
const btn =document.createElement(`a`);
btn.textContent="login";
btn.classList.add(`btn`);
btn.setAttribute(`title`,`el valor que usted le quiera dar`);
btn.setAttribute(`disabled`,``);// eventos
formulario.append(btn);
const validar = (event)=>{
    event.preventDefault()
    if (contrasena.value===`123`) {
        formulario.submit();
    } else {
        alert("Datos no validados");
    } 
}
btn_validar.addEventListener(`click`,validar)

// formulario.addEventListener(`click`);
// alert(`validando`)